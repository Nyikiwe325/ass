<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    
    <body class="body">
        <?php
        // put your code here
        ?>
        <center><h1 class="head">Tshimologong Survey</h1></center>
        <center><table class="table1" >
            <tr>
                <td><h3><a href="fillout.php"><center>Fill out Survey</center></a></h3></td>
        </tr>
        </table></br>
        <table class="table1">
        <tr>
            <td><h3><a href="view.php"><center>View Survey Result</center></a></h3></td>
        </tr>
        </table>
    </body></center>
        
</html>
